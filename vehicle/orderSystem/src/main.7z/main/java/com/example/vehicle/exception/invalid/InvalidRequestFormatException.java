package com.example.vehicle.exception.invalid;

import com.example.vehicle.exception.CustomException;
import com.example.vehicle.exception.ErrorCode;

public class InvalidRequestFormatException extends CustomException {
    public InvalidRequestFormatException() {
        super(ErrorCode.INVALID_REQUEST_FORMANT);
    }
}
