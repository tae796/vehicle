package com.example.vehicle.exception.invalid;

import com.example.vehicle.exception.CustomException;
import com.example.vehicle.exception.ErrorCode;

public class InvalidStatusException extends CustomException {
    public InvalidStatusException() {
        super(ErrorCode.INVALID_STATUS);
    }
}
