package com.example.vehicle.controller;

import com.example.vehicle.dto.request.VehicleRequestDto;
import com.example.vehicle.dto.response.VehicleResponseDto;
import com.example.vehicle.entity.Category;
import com.example.vehicle.entity.Vehicle;
import com.example.vehicle.service.RedisService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/redis")
public class RedisController {

    @Autowired
    private RedisService redisService;

//    @PostMapping
//    public String saveData(@RequestBody Vehicle vehicle) {
//        try {
//            redisService.saveToSet(vehicle);
//        }  catch (IllegalArgumentException e){
//            return e.getMessage();
//        }
//
//        return "Data saved successfully";
//    }
//
//    @GetMapping("/{categoryId}")
//    public List<Vehicle> getVehiclesByCategory(@PathVariable String category_name) {
//        // Category 엔티티를 DB에서 조회 (생략 가능)
//        Category category = new Category();
//        category.setName(category_name);
//
//        return redisService.getVehiclesByCategory(category);
//    }


    
    // brand, model, year로 데이터 가져오기
    @GetMapping
    public VehicleResponseDto getVehicleWithCategories(@RequestParam String brand,
                                                           @RequestParam String model,
                                                           @RequestParam Integer year) {
        return redisService.getVehicleWithCategories(brand, model, year);
    }



    @PostMapping
    public VehicleResponseDto createVehicle(@RequestBody VehicleRequestDto vehicleRequestDto) {
        return redisService.saveVehicle(vehicleRequestDto);
    }

    @GetMapping("/status/{status}")
    public List<VehicleResponseDto> getVehiclesByStatus(@PathVariable String status) {
        return redisService.getVehiclesByStatus(status);
    }

    @GetMapping("/category/{categoryName}")
    public List<VehicleResponseDto> getVehiclesByCategory(@PathVariable String categoryName) {
        return redisService.getVehiclesByCategory(categoryName);
    }

}