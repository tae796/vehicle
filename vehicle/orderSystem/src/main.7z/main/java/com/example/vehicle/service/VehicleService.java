package com.example.vehicle.service;


import com.example.vehicle.dto.OrderDto;
import com.example.vehicle.dto.request.DeleteOrderRequestDto;
import com.example.vehicle.dto.request.OrderRequestDto;
import com.example.vehicle.dto.request.UpdateStatusRequestDto;
import com.example.vehicle.entity.User;
import com.example.vehicle.entity.Vehicle;
import com.example.vehicle.enums.OrderStatus;
import com.example.vehicle.exception.invalid.DuplicateOrderIdException;
import com.example.vehicle.exception.invalid.InvalidStatusException;
import com.example.vehicle.exception.invalid.OrderNotFoundException;
import com.example.vehicle.repository.VehicleRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

@Slf4j
@Service
@RequiredArgsConstructor
public class VehicleService {
   @Autowired
   private VehicleRepository vehicleRepository;

    public List<Vehicle> getAllVehicle() {
        return vehicleRepository.findAll();
    }

    public Vehicle createvehicle(Vehicle vehicle) {
        return vehicleRepository.save(vehicle);
    }

    public Vehicle getVehicleById(Long id) {
        return vehicleRepository.findById(id).orElse(null);
    }

    public Vehicle getVehicleByModel(String model) {return vehicleRepository.findByModel(model);}

    public Vehicle updateVehicle(Long id, Vehicle vehicleDetails) {
        Vehicle vehicle = vehicleRepository.findById(id).orElse(null);
        if (vehicle != null) {
            vehicle.setBrand(vehicleDetails.getBrand());
            vehicle.setModel(vehicleDetails.getModel());
            vehicle.setYear(vehicleDetails.getYear());
            return vehicleRepository.save(vehicle);
        }
        return null;
    }

    public void deleteVehicle(Long id) {
        vehicleRepository.deleteById(id);
    }
}
