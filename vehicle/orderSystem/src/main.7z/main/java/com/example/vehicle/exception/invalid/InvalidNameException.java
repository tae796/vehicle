package com.example.vehicle.exception.invalid;

import com.example.vehicle.exception.CustomException;
import com.example.vehicle.exception.ErrorCode;

public class InvalidNameException extends CustomException {
    public InvalidNameException() {
        super(ErrorCode.INVALID_NAME);
    }
}
