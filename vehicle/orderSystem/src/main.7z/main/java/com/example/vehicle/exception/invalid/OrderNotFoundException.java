package com.example.vehicle.exception.invalid;

import com.example.vehicle.exception.CustomException;
import com.example.vehicle.exception.ErrorCode;

public class OrderNotFoundException extends CustomException {
    public OrderNotFoundException() {
        super(ErrorCode.ORDER_ID_NOT_FOUND);
    }
}
