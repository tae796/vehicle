package com.example.vehicle.exception.invalid;

import com.example.vehicle.exception.CustomException;
import com.example.vehicle.exception.ErrorCode;

public class InvalidOrderIdException extends CustomException {
    public InvalidOrderIdException() {
        super(ErrorCode.INVALID_ORDER_ID);
    }
}
